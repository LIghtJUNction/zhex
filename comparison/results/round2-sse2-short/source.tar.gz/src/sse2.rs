//! Baseline x86 SIMD for small buffers and bounded AVX2 tails.

#[cfg(target_arch = "x86")]
use core::arch::x86::*;
#[cfg(target_arch = "x86_64")]
use core::arch::x86_64::*;

use crate::{scalar, Error};

/// Caller guarantees SSE2 + OS support and output.len() == input.len() * 2.
#[inline]
#[target_feature(enable = "sse2")]
pub(crate) unsafe fn encode<const UPPER: bool>(input: &[u8], output: &mut [u8]) {
    let mut i = 0;
    // SAFETY: the compilation target guarantees CPU/OS SSE2 support. Each full
    // iteration reads 16 bytes and writes 32; the last partial vector reads only
    // 8 bytes and writes 16. Bounds are checked before every complete chunk.
    // Unaligned intrinsics need only byte alignment, and the shared input and
    // exclusively borrowed output cannot alias. The scalar tail stays bounded.
    unsafe {
        let mask = _mm_set1_epi8(15);
        let zero = _mm_set1_epi8(b'0' as i8);
        let nine = _mm_set1_epi8(9);
        let offset = _mm_set1_epi8(if UPPER { 7 } else { 39 });
        while input.len() - i >= 16 {
            let bytes = _mm_loadu_si128(input.as_ptr().add(i).cast());
            let lo = _mm_and_si128(bytes, mask);
            let hi = _mm_and_si128(_mm_srli_epi16(bytes, 4), mask);
            let lo = _mm_add_epi8(
                _mm_add_epi8(lo, zero),
                _mm_and_si128(_mm_cmpgt_epi8(lo, nine), offset),
            );
            let hi = _mm_add_epi8(
                _mm_add_epi8(hi, zero),
                _mm_and_si128(_mm_cmpgt_epi8(hi, nine), offset),
            );
            _mm_storeu_si128(
                output.as_mut_ptr().add(2 * i).cast(),
                _mm_unpacklo_epi8(hi, lo),
            );
            _mm_storeu_si128(
                output.as_mut_ptr().add(2 * i + 16).cast(),
                _mm_unpackhi_epi8(hi, lo),
            );
            i += 16;
        }
        if input.len() - i >= 8 {
            let bytes = _mm_loadl_epi64(input.as_ptr().add(i).cast());
            let lo = _mm_and_si128(bytes, mask);
            let hi = _mm_and_si128(_mm_srli_epi16(bytes, 4), mask);
            let lo = _mm_add_epi8(
                _mm_add_epi8(lo, zero),
                _mm_and_si128(_mm_cmpgt_epi8(lo, nine), offset),
            );
            let hi = _mm_add_epi8(
                _mm_add_epi8(hi, zero),
                _mm_and_si128(_mm_cmpgt_epi8(hi, nine), offset),
            );
            _mm_storeu_si128(
                output.as_mut_ptr().add(2 * i).cast(),
                _mm_unpacklo_epi8(hi, lo),
            );
            i += 8;
        }
    }
    scalar::encode::<UPPER>(&input[i..], &mut output[2 * i..]);
}

/// Caller guarantees SSE2 + OS support, even input and exact half-sized output.
/// `offset` is the start of this slice in the original input.
#[inline]
#[target_feature(enable = "sse2")]
pub(crate) unsafe fn decode(input: &[u8], output: &mut [u8], offset: usize) -> Result<(), Error> {
    let mut i = 0;
    // SAFETY: the compilation target guarantees CPU/OS SSE2 support. Each loop
    // reads exactly 16 in-bounds text bytes, then writes 8 in-bounds result bytes.
    // These unaligned accesses need only byte alignment and the slices cannot
    // alias. Only the low 16 movemask bits describe loaded bytes; invalid input
    // is rejected before a store. Scalar tail indexing preserves the offset.
    unsafe {
        while input.len() - i >= 16 {
            let text = _mm_loadu_si128(input.as_ptr().add(i).cast());
            let digits = _mm_add_epi8(text, _mm_set1_epi8(80));
            let letters = _mm_add_epi8(_mm_or_si128(text, _mm_set1_epi8(32)), _mm_set1_epi8(31));
            let is_digit = _mm_cmpgt_epi8(_mm_set1_epi8(-118), digits);
            let is_letter = _mm_cmpgt_epi8(_mm_set1_epi8(-122), letters);
            let invalid = !(_mm_movemask_epi8(_mm_or_si128(is_digit, is_letter)) as u16);
            if invalid != 0 {
                let index = i + invalid.trailing_zeros() as usize;
                return Err(Error::InvalidByte {
                    index: offset + index,
                    byte: input[index],
                });
            }
            let nibbles = _mm_add_epi8(
                _mm_and_si128(text, _mm_set1_epi8(15)),
                _mm_and_si128(is_letter, _mm_set1_epi8(9)),
            );
            let pairs = _mm_or_si128(
                _mm_and_si128(_mm_slli_epi16(nibbles, 4), _mm_set1_epi16(255)),
                _mm_srli_epi16(nibbles, 8),
            );
            let bytes = _mm_packus_epi16(pairs, _mm_setzero_si128());
            _mm_storel_epi64(output.as_mut_ptr().add(i / 2).cast(), bytes);
            i += 16;
        }
    }
    scalar::decode(&input[i..], &mut output[i / 2..], offset + i)
}
