//! AVX2 kernels; all memory operations use complete, unaligned chunks.

#[cfg(target_arch = "x86")]
use core::arch::x86::*;
#[cfg(target_arch = "x86_64")]
use core::arch::x86_64::*;

use crate::{scalar, Error};

#[inline]
pub(crate) fn available() -> bool {
    #[cfg(target_feature = "avx2")]
    {
        // A binary compiled for AVX2 already requires CPU and OS AVX2 support.
        true
    }
    #[cfg(not(target_feature = "avx2"))]
    {
        use core::sync::atomic::{AtomicU8, Ordering};
        static DETECTED: AtomicU8 = AtomicU8::new(0);
        let cached = DETECTED.load(Ordering::Relaxed);
        if cached != 0 {
            return cached == 2;
        }
        let supported = detect();
        // This caches a value, not other memory; concurrent duplicate detection
        // is harmless. No acquire/release synchronization is needed.
        DETECTED.store(if supported { 2 } else { 1 }, Ordering::Relaxed);
        supported
    }
}

#[cfg(not(target_feature = "avx2"))]
fn detect() -> bool {
    // SAFETY: supported x86 targets have CPUID; SGX is excluded by cfg.
    // detect_with calls XGETBV only after CPUID confirms XSAVE, OSXSAVE and AVX.
    // XCR0 exists; these register-only operations have no memory, alignment or
    // alias requirements. CPUID itself also requires unsafe on the MSRV.
    unsafe { detect_with(|leaf| __cpuid_count(leaf, 0), || _xgetbv(0)) }
}

#[cfg(not(target_feature = "avx2"))]
fn detect_with(cpuid: impl Fn(u32) -> CpuidResult, xcr0: impl Fn() -> u64) -> bool {
    if cpuid(0).eax < 7 {
        return false;
    }
    let required = (1 << 26) | (1 << 27) | (1 << 28);
    // Short-circuiting is essential: XGETBV needs all three prerequisite bits.
    // XCR0 bits 1 and 2 require OS support for both XMM and YMM state.
    if cpuid(1).ecx & required != required || xcr0() & 6 != 6 {
        return false;
    }
    cpuid(7).ebx & (1 << 5) != 0
}

/// Caller guarantees AVX2 + OS support and output.len() == input.len() * 2.
#[target_feature(enable = "avx2")]
pub(crate) unsafe fn encode<const UPPER: bool>(input: &[u8], output: &mut [u8]) {
    let mut i = 0;
    // SAFETY: CPU/OS AVX2 and exact disjoint slice lengths are caller invariants.
    // Each encode16 reads exactly 16 bytes and its store writes exactly 32.
    // Remaining-length checks bound all four unrolled loads/stores and the tail
    // loop. The alphabet is 32 initialized bytes; every access is unaligned.
    unsafe {
        let alphabet = if UPPER {
            b"0123456789ABCDEF0123456789ABCDEF"
        } else {
            b"0123456789abcdef0123456789abcdef"
        };
        let table = _mm256_loadu_si256(alphabet.as_ptr().cast());
        let mask = _mm256_set1_epi8(15);
        while input.len() - i >= 64 {
            let a = encode16(input.as_ptr().add(i), table, mask);
            let b = encode16(input.as_ptr().add(i + 16), table, mask);
            let c = encode16(input.as_ptr().add(i + 32), table, mask);
            let d = encode16(input.as_ptr().add(i + 48), table, mask);
            _mm256_storeu_si256(output.as_mut_ptr().add(2 * i).cast(), a);
            _mm256_storeu_si256(output.as_mut_ptr().add(2 * i + 32).cast(), b);
            _mm256_storeu_si256(output.as_mut_ptr().add(2 * i + 64).cast(), c);
            _mm256_storeu_si256(output.as_mut_ptr().add(2 * i + 96).cast(), d);
            i += 64;
        }
        while input.len() - i >= 16 {
            let bytes = encode16(input.as_ptr().add(i), table, mask);
            _mm256_storeu_si256(output.as_mut_ptr().add(2 * i).cast(), bytes);
            i += 16;
        }
    }
    scalar::encode::<UPPER>(&input[i..], &mut output[2 * i..]);
}

/// AVX2 and 16 readable input bytes are required; table/mask are initialized.
#[inline]
#[target_feature(enable = "avx2")]
unsafe fn encode16(input: *const u8, table: __m256i, mask: __m256i) -> __m256i {
    // SAFETY: caller proves AVX2 and 16 initialized readable bytes. loadu needs
    // byte alignment; this helper only reads, with no alias or store condition.
    unsafe {
        let wide = _mm256_cvtepu8_epi16(_mm_loadu_si128(input.cast()));
        let indices = _mm256_and_si256(
            _mm256_or_si256(_mm256_srli_epi16(wide, 4), _mm256_slli_epi16(wide, 8)),
            mask,
        );
        _mm256_shuffle_epi8(table, indices)
    }
}

/// Caller guarantees AVX2 + OS support, even input and output.len() == input.len()/2.
#[target_feature(enable = "avx2")]
pub(crate) unsafe fn decode(input: &[u8], output: &mut [u8]) -> Result<(), Error> {
    let mut i = 0;
    // SAFETY: CPU/OS AVX2 and exact disjoint lengths are caller invariants. The
    // first loop reads four bounded 32-byte chunks and writes two 32-byte chunks.
    // The second reads 32 and writes 16. Unaligned accesses need byte alignment.
    // Each group's complete validity is checked before any output store. On
    // error, scalar decoding recovers the first index in order and writes only
    // its valid prefix. The final bounded tail preserves the original offset.
    unsafe {
        while input.len() - i >= 128 {
            let (a, va) = decode32(_mm256_loadu_si256(input.as_ptr().add(i).cast()));
            let (b, vb) = decode32(_mm256_loadu_si256(input.as_ptr().add(i + 32).cast()));
            let (c, vc) = decode32(_mm256_loadu_si256(input.as_ptr().add(i + 64).cast()));
            let (d, vd) = decode32(_mm256_loadu_si256(input.as_ptr().add(i + 96).cast()));
            let valid = _mm256_and_si256(_mm256_and_si256(va, vb), _mm256_and_si256(vc, vd));
            if _mm256_movemask_epi8(valid) != -1 {
                return scalar::decode(&input[i..], &mut output[i / 2..], i);
            }
            let ab = _mm256_permute4x64_epi64(_mm256_packus_epi16(a, b), 0xd8);
            let cd = _mm256_permute4x64_epi64(_mm256_packus_epi16(c, d), 0xd8);
            _mm256_storeu_si256(output.as_mut_ptr().add(i / 2).cast(), ab);
            _mm256_storeu_si256(output.as_mut_ptr().add(i / 2 + 32).cast(), cd);
            i += 128;
        }
        while input.len() - i >= 32 {
            let (pairs, valid) = decode32(_mm256_loadu_si256(input.as_ptr().add(i).cast()));
            let invalid = !(_mm256_movemask_epi8(valid) as u32);
            if invalid != 0 {
                let index = i + invalid.trailing_zeros() as usize;
                return Err(Error::InvalidByte {
                    index,
                    byte: input[index],
                });
            }
            let bytes = _mm_packus_epi16(
                _mm256_castsi256_si128(pairs),
                _mm256_extracti128_si256(pairs, 1),
            );
            _mm_storeu_si128(output.as_mut_ptr().add(i / 2).cast(), bytes);
            i += 32;
        }
        #[cfg(target_feature = "sse2")]
        return crate::sse2::decode(&input[i..], &mut output[i / 2..], i);
    }
    #[cfg(not(target_feature = "sse2"))]
    scalar::decode(&input[i..], &mut output[i / 2..], i)
}

/// Requires AVX2. Returns decoded u16 pairs and the validity mask of all bytes.
#[inline]
#[target_feature(enable = "avx2")]
#[allow(unused_unsafe)] // Register intrinsics require unsafe on the MSRV.
unsafe fn decode32(text: __m256i) -> (__m256i, __m256i) {
    // SAFETY: AVX2 is a caller invariant. All operands are initialized registers;
    // there are no memory, alignment or alias conditions in this helper.
    unsafe {
        let digits = _mm256_add_epi8(text, _mm256_set1_epi8(80));
        let letters = _mm256_add_epi8(
            _mm256_or_si256(text, _mm256_set1_epi8(32)),
            _mm256_set1_epi8(31),
        );
        let is_digit = _mm256_cmpgt_epi8(_mm256_set1_epi8(-118), digits);
        let is_letter = _mm256_cmpgt_epi8(_mm256_set1_epi8(-122), letters);
        let nibbles = _mm256_add_epi8(
            _mm256_and_si256(text, _mm256_set1_epi8(15)),
            _mm256_and_si256(is_letter, _mm256_set1_epi8(9)),
        );
        (
            _mm256_maddubs_epi16(nibbles, _mm256_set1_epi16(0x0110)),
            _mm256_or_si256(is_digit, is_letter),
        )
    }
}

#[cfg(test)]
mod tests {
    extern crate std;

    #[test]
    fn detector_agrees_with_standard_library() {
        assert_eq!(super::available(), std::is_x86_feature_detected!("avx2"));
    }

    #[cfg(not(target_feature = "avx2"))]
    #[test]
    fn detection_rejects_missing_cpu_or_os_support_in_order() {
        const REQUIRED: u32 = (1 << 26) | (1 << 27) | (1 << 28);
        fn probe(max_leaf: u32, ecx: u32, xcr0: u64, ebx: u32) -> bool {
            let step = core::cell::Cell::new(0);
            super::detect_with(
                |leaf| {
                    let mut result = super::CpuidResult {
                        eax: 0,
                        ebx: 0,
                        ecx: 0,
                        edx: 0,
                    };
                    match leaf {
                        0 => {
                            assert_eq!(step.replace(1), 0);
                            result.eax = max_leaf;
                        }
                        1 => {
                            assert!(max_leaf >= 7);
                            assert_eq!(step.replace(2), 1);
                            result.ecx = ecx;
                        }
                        7 => {
                            assert_eq!(xcr0 & 6, 6, "leaf 7 before OS support");
                            assert_eq!(step.replace(4), 3);
                            result.ebx = ebx;
                        }
                        _ => panic!("unexpected CPUID leaf"),
                    }
                    result
                },
                || {
                    assert_eq!(ecx & REQUIRED, REQUIRED, "XGETBV before prerequisites");
                    assert_eq!(step.replace(3), 2);
                    xcr0
                },
            )
        }
        for max_leaf in [0, 1, 6] {
            assert!(!probe(max_leaf, REQUIRED, 6, 32));
        }
        for bit in [26, 27, 28] {
            assert!(!probe(7, REQUIRED & !(1 << bit), 6, 32));
        }
        for xcr0 in [0, 2, 4] {
            assert!(!probe(7, REQUIRED, xcr0, 32));
        }
        assert!(!probe(7, REQUIRED, 6, 0));
        assert!(probe(7, REQUIRED, 6, 32));
        assert!(probe(u32::MAX, u32::MAX, u64::MAX, u32::MAX));
    }
}
