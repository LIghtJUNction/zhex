Pinned zhex implementation from commit 86f569a, before the second optimization pass.

Only the crate-level no_std attribute and module-local import paths are adapted for inclusion in this unpublished benchmark binary. Code and error semantics are otherwise unchanged. MIT license from the repository root applies.
